var request = require('request');
var rp = require('request-promise');
var Alexa = require('alexa-sdk');

var APP_ID = "amzn1.ask.skill.04d6194a-6ba1-4531-a5a8-c6afd7782124";
var SKILL_NAME = "AirWatch";
var TOTAL_DEVICES_MESSAGE = "The total number of devices in your environment is : ";
var HELP_REPROMPT = "What can I help you with?";
var STOP_MESSAGE = "Goodbye!";
var speechOutput = "";

const awapikey = process.env['awapikey'];
const awapi = process.env['awapi'];
const awadminpw = process.env['awadminpw'];
const awadminun = process.env['awadminun'];
const ogid = process.env['organization_group_id'];
const awds = process.env['awds'];
const awseg = process.env['awseg'];


var LIST_OF_DEPLOYMENT_DETAIL = {
	"total": "Total",
	"windows mobile": "WindowsMobile",
	"apple ios": "Apple",
	"apple": "Apple",
	"ios": "Apple",
	"android": "Android",
	"windows pc": "WindowsPC",
	"apple osx": "AppleOsX",
	"mac os": "AppleOsX",
	"mac": "AppleOsX",
	"windows phone eight": "WindowsPhone8",
	"windows phone 8": "WindowsPhone8",
	"windows rt": "WindowsRT",
	"blackberry ten": "BlackBerry10",
	"apple tv": "AppleTv",
	"chromebook": "ChromeBook",
	"corporate dedicated": "CorporateDedicated",
	"corporate shared": "CorporateShared",
	"employee owned": "EmployeeOwned",
	"employee": "EmployeeOwned",
	"byod": "EmployeeOwned",
	"byo": "EmployeeOwned",
	"undefined": "Undefined",
	"compromised": "Compromised",
	"no passcode": "NoPasscode",
	"not encrypted": "NotEncrypted",
	"enrolled": "Enrolled",
	"in rolled": "Enrolled",
	"valid": "Enrolled",
	"unenrolled": "Unenrolled",
	"un in rolled": "Unenrolled",
	"registered": "Registered"
};

function getDeploymentDetailString(detail, body) {
	console.log("in function getDeploymentDetailString");
	//Given a deployment detail and a response body, return the deployment detail string 
	console.log("detail var passed to getDeploymentDetailString is " + detail);
	var s;

	if (detail=='Total')
	{
		d = body.TotalDevices;
		s = "The number of total devices is: " + d;
	} else if (detail == 'Compromised')
	{
		d = body.Security.Compromised;
		s = "The number of compromised devices is: " + d;
	} else if (detail == 'NoPasscode')
	{
		d = body.Security.NoPasscode;
		s = "The number of devices with no passcode is: " + d;
	} else if (detail == 'NotEncrypted')
	{
		d = body.Security.NotEncrypted;
		s = "The number of devices that are not encrypted is: " + d;
	} else if (detail == 'CorporateDedicated')
	{
		d = body.Ownership.CorporateDedicated;
		s = "The number of corporate dedicated devices is: " + d;
	} else if (detail == 'CorporateShared')
	{
		d = body.Ownership.CorporateShared;
		s = "The number of corporate shared devices is: " + d;
	} else if (detail == 'EmployeeOwned')
	{
		d = body.Ownership.EmployeeOwned;
		s = "The number of employee owned devices is: " + d;
	} else if (detail == 'Undefined')
	{
		d = body.Ownership.Undefined;
		s = "The number of undefined devices is: " + d;
	} else if (detail == 'WindowsMobile')
	{
		d = body.Platforms[detail];
		s = "The number of windows mobile devices is: " + d;
	} else if (detail == 'Apple')
	{
		d = body.Platforms[detail];
		s = "The number of i.o.s. devices is: " + d;
	} else if (detail == 'Android')
	{
		d = body.Platforms[detail];
		s = "The number of android devices is: " + d;
	} else if (detail == 'WindowsPC')
	{
		d = body.Platforms[detail];
		s = "The number of P.C. devices is: " + d;
	} else if (detail == 'AppleOsX')
	{
		d = body.Platforms[detail];
		s = "The number of Mac OS devices is: " + d;
	} else if (detail == 'WindowsPhone8')
	{
		d = body.Platforms[detail];
		s = "The number of Windows Phone eight devices is: " + d;
	} else if (detail == 'WindowsRT')
	{
		d = body.Platforms[detail];
		s = "The number of Windows R.T. devices is: " + d;
	} else if (detail == 'BlackBerry10')
	{
		d = body.Platforms[detail];
		s = "The number of blackberry ten devices is: " + d;
	} else if (detail == 'AppleTv')
	{
		d = body.Platforms[detail];
		s = "The number of Apple T.V. devices is: " + d;
	} else if (detail == 'ChromeBook')
	{
		d = body.Platforms[detail];
		s = "The number of chrome book devices is: " + d;
	} else if (detail == 'Enrolled')
	{
		d = body.EnrollmentStatus[detail];
		s = "The number of enrolled devices is: " + d;
	} else if (detail == 'Unenrolled')
	{
		d = body.EnrollmentStatus[detail];
		s = "The number of unenrolled devices is: " + d;
	} else if (detail == 'Registered')
	{
		d = body.EnrollmentStatus[detail];
		s = "The number of registered devices is: " + d;
	} else {
		s = "Sorry, I was not able to recognize the deployment detail you are looking for. Try Android or Mac."
	}
	console.log(s);
	return s;
};

function getDeviceTypebyNumber(detail) {
	console.log("in function getDeviceTypebyNumber");
	//Given a deployment detail and a response body, return the deployment detail string 
	console.log("detail var passed to getDeviceTypebyNumber is " + detail);
	var s;

	if (detail == '1')
	{
		s = "Windows Mobile";
	} else if (detail == '2')
	{
		s = "Apple iOS";
	} else if (detail == '3')
	{
		s = "BlackBerry";
	} else if (detail == '4')
	{
		s = "Symbian";
	} else if (detail == '5')
	{
		s = "Android";
	} else if (detail == '8')
	{
		s = "Windows Phone";
	} else if (detail == '9')
	{
		s = "Windows PC";
	} else if (detail == '10')
	{
		s = "Mac OS";
	} else if (detail == '11')
	{
		s = "Windows Phone eight";
	} else if (detail == '12')
	{
		s = "Windows RT";
	}else {
		s = "not sure"
	}
	console.log(s);
	return s;
};

function createOptionsdevicecount() {
	console.log("in function createOptionsdevicecount used by devicessummary");
    // load request options variable
    var options = { method: 'GET',
		url: (awapi + '/api/mdm/devices/devicecountinfo'),
//		qs: { organizationgroupid: ogid },
		headers: 
			{ 'content-type': 'application/json',
			   'authorization': "Basic " + new Buffer(awadminun + ":" + awadminpw).toString("base64"),
			   'aw-tenant-code': awapikey},
		transform: function (body) {
			return JSON.parse(body);
		}
	};
	return options;
};

function createOptionsInternalApp(name) {
	console.log("in function createOptionsInternalApp");
    // load request options variable
    var options = { method: 'GET',
		url: (awapi + '/api/mam/apps/search?type=App&applicationtype=Internal&applicationname='+ name),
		headers: 
			{ 'content-type': 'application/json',
			   'authorization': "Basic " + new Buffer(awadminun + ":" + awadminpw).toString("base64"),
			   'aw-tenant-code': awapikey},
		transform: function (body) {
			return JSON.parse(body);
		}
	};
	return options;
};

function createOptionsPublicApp(name) {
	console.log("in function createOptionsPublicApp");
    // load request options variable
    var options = { method: 'GET',
		url: (awapi + '/api/mam/apps/search?type=App&applicationtype=Public&applicationname='+ name),
		headers: 
			{ 'content-type': 'application/json',
			   'authorization': "Basic " + new Buffer(awadminun + ":" + awadminpw).toString("base64"),
			   'aw-tenant-code': awapikey},
		transform: function (body) {
			return JSON.parse(body);
		}
	};
	return options;
};

function createOptionsVPPApp(name) {
	console.log("in function createOptionsVPPApp");
    // load request options variable
    var options = { method: 'GET',
		url: (awapi + '/api/mam/apps/purchased/search?applicationname='+ name),
		headers: 
			{ 'content-type': 'application/json',
			   'authorization': "Basic " + new Buffer(awadminun + ":" + awadminpw).toString("base64"),
			   'aw-tenant-code': awapikey},
		transform: function (body) {
			return JSON.parse(body);
		}
	};
	return options;
};

function createOptionsGetVersion() {
	console.log("in function createOptionsGetVersion");
    // load request options variable
    var options = { method: 'GET',
		url: (awapi + '/api/system/info'),
		headers: 
			{ 'content-type': 'application/json',
			   'authorization': "Basic " + new Buffer(awadminun + ":" + awadminpw).toString("base64"),
			   'aw-tenant-code': awapikey},
		transform: function (body) {
			return JSON.parse(body);
		}
	};
	return options;
};

function createOptionsAPIUp() {
	console.log("in function createOptionsSystemUp");
    // load request options variable
    var options = { method: 'GET',
		url: (awapi),
		resolveWithFullResponse: true
	};
	return options;
};

function createOptionsDSUp() {
	console.log("in function createOptionsDSUp");
    // load request options variable
    var options = { method: 'GET',
		url: (awds + "/DeviceManagement/enrollment"),
		resolveWithFullResponse: true
	};
	return options;
};

function createOptionsSEGUp() {
	console.log("in function createOptionsSEGUp");
    // load request options variable
    var options = { method: 'GET',
		url: (awseg + "/Microsoft-Server-Activesync"),
		resolveWithFullResponse: true
	};
	return options;
};

function createOptionsDevicesDaysAgo(date) {
	console.log("in function createOptionsDevicesDaysAgo");
    // load request options variable
    var options = { method: 'GET',
		url: (awapi + "/api/mdm/devices/search?seensince=" + date),
		headers: 
			{ 'content-type': 'application/json',
			   'authorization': "Basic " + new Buffer(awadminun + ":" + awadminpw).toString("base64"),
			   'aw-tenant-code': awapikey},
		transform: function (body) {
			return JSON.parse(body);
		}
	};
	return options;
};

function convertDate(date) {
  var yyyy = date.getFullYear().toString();
  var mm = (date.getMonth()+1).toString();
  var dd  = date.getDate().toString();

  var mmChars = mm.split('');
  var ddChars = dd.split('');

  return yyyy + '-' + (mmChars[1]?mm:"0"+mmChars[0]) + '-' + (ddChars[1]?dd:"0"+ddChars[0]);
}


exports.handler = function(event, context, callback) {
	var alexa = Alexa.handler(event, context, callback);
	alexa.APP_ID = APP_ID;
	alexa.registerHandlers(handlers);
	alexa.execute();
};

var handlers = {
	'LaunchRequest': function () {
		console.log("in function launchrequest..... why");
        this.emit('DevicesSummary');
    },
    'TotalDevices': function() {
	    var obj = this; 
		rp(createOptionsdevicecount())
			.then(
				function ($) {
					totald = $.TotalDevices;
					securityc = $.Security.Compromised;
					ownershipcd = $.Ownership.CorporateDedicated;
					ownershipcs = $.Ownership.CorporateShared;
					ownershipe = $.Ownership.EmployeeOwned;
					ownershipu = $.Ownership.Undefined;
					enroll = $.EnrollmentStatus.Enrolled;
					unenroll = $.EnrollmentStatus.Unnrolled;
					registered = $.EnrollmentStatus.Registered;
					ios = $.Platforms.Apple;
					android = $.Platforms.Android;
					
					speechOutput = "There is a total of " + totald + " devices of which " + enroll + " are enrolled. " + securityc + " of them are compromised. " + ownershipe + " are employee owned and " + ownershipcd + " are corporate dedicated. The number of iOS and Android is " + ios + " and " + android;
					console.log(speechOutput);
					obj.emit(':tellWithCard', speechOutput, SKILL_NAME);
			})
			.catch(
				function (err) {
				console.log(err);
		});

   	},
	'DevicesSummary': function() {
		console.log("in function DevicesSummary");
		//Get slot from request
	    var detailSlot = this.event.request.intent.slots.DeploymentDetail;
        var detailName;
        if (detailSlot && detailSlot.value) {
            detailName = detailSlot.value.toLowerCase();
        }

        console.log(detailName);
        var detail = LIST_OF_DEPLOYMENT_DETAIL[detailName];
        console.log(detail);

        //If detail exists then get deployment details
        if (detail) {
        	//Save off local Alexa response var for use within the promise
        	var obj = this;

			rp(createOptionsdevicecount())
				.then(
					function ($) {
						var dds = getDeploymentDetailString(detail, $);
						speechOutput = dds;
						console.log(speechOutput);
						obj.emit(':tellWithCard', speechOutput, SKILL_NAME);
				})
				.catch(
					function (err) {
						console.log(err);
					}
				);
            
        } else {
            var speechOutput = "I could not find the details for the number of your " + detailName +" devices.  Try Android or Mac." ;
	        var reprompt = HELP_REPROMPT;
	        this.emit(':ask', speechOutput, reprompt);
        }
    
   	},
	'InternalApp': function() {
		console.log("in function Internal App");
		//Get slot from request
	    var detailSlot = this.event.request.intent.slots.InternalAppDetail;
        var detail;
        if (detailSlot && detailSlot.value) {
            detail = detailSlot.value.toLowerCase();
        }
        console.log(detail);

        //If detail exists then get internalappdetails
        if (detail) {
        	//Save off local Alexa response var for use within the promise
        	var obj = this;

			rp(createOptionsInternalApp(detail))
				.then(
					function ($) {
						//find total number of apps returned
						l = $.Total;
						console.log("The number of apps returned is " + l);
						//check if any apps returned
						if (l > 0) {	
							app = 0;
							speechOutput1 = " ";
							for (var i = 0; i < l; i++) {
								console.log("This is iteration of loop number" + i);
								//check app device type
								$dtype = getDeviceTypebyNumber($.Application[i].Platform);
								//check if app is Active, if not skip
								if ($.Application[i].Status == 'Active') {
									app += 1;
									speechOutput1 += "The " + $dtype + " app " + $.Application[i].ApplicationName + " version " + $.Application[i].AppVersion + " is found. It is assigned to " + $.Application[i].AssignedDeviceCount + " devices and installed on " + $.Application[i].InstalledDeviceCount + ". ";	
								}
							}
							speechOutput = "The number of applications is " + app + ". " + speechOutput1;
							console.log(speechOutput);
							obj.emit(':tellWithCard', speechOutput, SKILL_NAME);
							
						} else {
							speechOutput = "There are no apps found with the name: " + detail;
							var reprompt = HELP_REPROMPT;
							this.emit(':ask', speechOutput, reprompt);
							
						}
				})
				.catch(
					function (err) {
						console.log(err);
					}
				);
            
        } else {
            var speechOutput = "I did not understand the internal app " + detail +". Try again.";
	        var reprompt = HELP_REPROMPT;
	        this.emit(':ask', speechOutput, reprompt);
        }
    
   	},
	'PublicApp': function() {
		console.log("in function Public App");
		//Get slot from request
	    var detailSlot = this.event.request.intent.slots.PublicAppDetail;
        var detail;
        if (detailSlot && detailSlot.value) {
            detail = detailSlot.value.toLowerCase();
        }
        console.log(detail);

        //If detail exists then get internalappdetails
        if (detail) {
        	//Save off local Alexa response var for use within the promise
        	var obj = this;

			rp(createOptionsPublicApp(detail))
				.then(
					function ($) {
						//find total number of apps returned
						l = $.Total;
						console.log("The number of apps returned is " + l);
						//check if any apps returned
						if (l > 0) {	
							app = 0;
							speechOutput1 = " ";
							for (var i = 0; i < l; i++) {
								console.log("This is iteration of loop number" + i);
								//check app device type
								$dtype = getDeviceTypebyNumber($.Application[i].Platform);
								//check if app is Active, if not skip
								if ($.Application[i].Status == 'Active') {
									app += 1;
									speechOutput1 += "The " + $dtype + " app " + $.Application[i].ApplicationName + "  is found. It is assigned to " + $.Application[i].AssignedDeviceCount + " devices and installed on " + $.Application[i].InstalledDeviceCount + ". ";	
								}
							}
							speechOutput = "The number of applications is " + app + ". " + speechOutput1;
							console.log(speechOutput);
							obj.emit(':tellWithCard', speechOutput, SKILL_NAME);
							
						} else {
							speechOutput = "There are no apps found with the name: " + detail;
							var reprompt = HELP_REPROMPT;
							this.emit(':ask', speechOutput, reprompt);
							
						}
				})
				.catch(
					function (err) {
						console.log(err);
						speechOutput = "There was an issue searching for the public app. Try again. ";
						var reprompt = HELP_REPROMPT;
						this.emit(':ask', speechOutput, reprompt);
					}
				);
            
        } else {
            var speechOutput = "I did not understand the public app " + detail +". Try again.";
	        var reprompt = HELP_REPROMPT;
	        this.emit(':ask', speechOutput, reprompt);
        }
    
   	},
	'VPPApp': function() {
		console.log("in function VPPApp");
		//Get slot from request
	    var detailSlot = this.event.request.intent.slots.VPPAppDetail;
        var detail;
		console.log("detailslot " + detailSlot);
		console.log("detailslot.value " + detailSlot.value);
        if (detailSlot && detailSlot.value) {
            detail = detailSlot.value.toLowerCase();
        }
        console.log("detail after " + detail);

        //If detail exists then get internalappdetails
        if (detail) {
        	//Save off local Alexa response var for use within the promise
        	var obj = this;

			rp(createOptionsVPPApp(detail))
				.then(
					function ($) {
						//find total number of apps returned
						l = $.Total;
						console.log("The number of apps returned is " + l);
						//check if any apps returned
						if (l > 0) {	
							app = 0;
							speechOutput1 = " ";
							for (var i = 0; i < l; i++) {
								console.log("This is iteration of loop number" + i);
								//check if app is Active, if not skip
								if ($.Application[i].AssignmentStatus == 'Assigned' && $.Application[i].hasOwnProperty('ManagedDistribution')){
									app += 1;
									speechOutput1 += "The iOS app " + $.Application[i].ApplicationName + "  was found and eligible for managed distribution. It is deployed " + $.Application[i].Deployment.AssignmentType + ". " + $.Application[i].ManagedDistribution.Purchased + " licenses have been purchased of which " + $.Application[i].ManagedDistribution.Burned + " have been burned. ";	
								} else if ($.Application[i].AssignmentStatus == 'Assigned' && $.Application[i].hasOwnProperty('RedeemableCodes')) {
									app += 1;
									speechOutput1 += "The iOS app " + $.Application[i].ApplicationName + "  was found and not eligible for managed distribution. It is deployed " + $.Application[i].Deployment.AssignmentType + ". " + $.Application[i].RedeemableCodes.Purchased + " licenses have been purchased of which " + $.Application[i].ManagedDistribution.Burned + " have been burned. ";	
								}
							}
							speechOutput = "The number of apps found is " + app + ". " + speechOutput1;
							console.log(speechOutput);
							obj.emit(':tellWithCard', speechOutput, SKILL_NAME);
							
						} else {
							speechOutput = "There are no apps found with the name: " + detail;
							var reprompt = HELP_REPROMPT;
							this.emit(':ask', speechOutput, reprompt);
							
						}
				})
				.catch(
					function (err) {
						console.log(err);
					}
				);
            
        } else {
            var speechOutput = "I did not understand the purchased app " + detail +". Try again.";
	        var reprompt = HELP_REPROMPT;
	        this.emit(':ask', speechOutput, reprompt);
        }
    
   	},
	'GetVersion': function() {
	    var obj = this; 
		rp(createOptionsGetVersion())
			.then(
				function ($) {
					
					speechOutput = "AirWatch is currently running version " + $.ProductVersion;
					console.log(speechOutput);
					obj.emit(':tellWithCard', speechOutput, SKILL_NAME);
			})
			.catch(
				function (err) {
				console.log(err);
		});

   	},
	'SystemAPIUp': function() {
	    var obj = this; 
		if (awapi.indexOf('http') > -1){
			rp(createOptionsAPIUp())
				.then(
					function ($) {
						console.log($.statusCode)
						if($.statusCode == 200 ) {
							speechOutput = "AirWatch API is healthy with a status code of " + $.statusCode;
						} else {
							speechOutput = "AirWatch API is unhealthy with a status code of " + $.statusCode;
						}
						console.log(speechOutput);
						obj.emit(':tellWithCard', speechOutput, SKILL_NAME);
				})
				.catch(
					function (err) {
						
						console.log(err.statusCode)
						speechOutput = "AirWatch API is returning an error status code of " + err.statusCode;
						console.log(speechOutput);
						obj.emit(':tellWithCard', speechOutput, SKILL_NAME);
						console.log(err);
			});
		} else {
			
			console.log("AW API URL not valid")
			speechOutput = "AirWatch API URL value in LAMBDA not set properly";
			console.log(speechOutput);
			obj.emit(':tellWithCard', speechOutput, SKILL_NAME);
			
		}
   	},
	'SystemDSUp': function() {
	    var obj = this; 
		if (awapi.indexOf('http') > -1){
			rp(createOptionsDSUp())
				.then(
					function ($) {
						console.log($.statusCode)
						if($.statusCode == 200 ) {
							speechOutput = "AirWatch Device Services is healthy with a status code of " + $.statusCode;
						} else {
							speechOutput = "AirWatch Device Services is unhealthy with a status code of " + $.statusCode;
						}
						console.log(speechOutput);
						obj.emit(':tellWithCard', speechOutput, SKILL_NAME);
				})
				.catch(
					function (err) {
						
						console.log(err.statusCode)
						speechOutput = "AirWatch Device Services is returning an error status code of " + err.statusCode;
						console.log(speechOutput);
						obj.emit(':tellWithCard', speechOutput, SKILL_NAME);
						console.log(err);
			});
		} else {
			
			console.log("AW DS URL not valid")
			speechOutput = "AirWatch Device Services URL value in LAMBDA not set properly";
			console.log(speechOutput);
			obj.emit(':tellWithCard', speechOutput, SKILL_NAME);
			
		}
	},
	'SystemSEGUp': function() {
	    var obj = this; 
		if (awapi.indexOf('http') > -1){
			rp(createOptionsSEGUp())
				.then(
					function ($) {
						console.log($.statusCode)
						speechOutput = "AirWatch Secure Email Gateway is unhealthy with a status code of " + $.statusCode;
						console.log(speechOutput);
						obj.emit(':tellWithCard', speechOutput, SKILL_NAME);
				})
				.catch(
					function (err) {
						
						console.log(err.statusCode)
						if(err.statusCode == 401 ) {
							speechOutput = "AirWatch Secure Email Gateway is returning healthy with an expected status code of " + err.statusCode;
						} else {
							speechOutput = "AirWatch Secure Email Gateway is unhealthy with a status code of " + err.statusCode;
						}
						console.log(speechOutput);
						obj.emit(':tellWithCard', speechOutput, SKILL_NAME);
						console.log(err);
			});
		} else {
			
			console.log("AW SEG URL not valid")
			speechOutput = "AirWatch Secure Email Gateway URL value in LAMBDA not set properly";
			console.log(speechOutput);
			obj.emit(':tellWithCard', speechOutput, SKILL_NAME);
			
		}
   	},
	'DevicesDaysAgo': function() {
		console.log("in function DevicesDaysAgo");
		//Get slot from request
	    var detailSlot = this.event.request.intent.slots.Days;
        var detail = detailSlot.value;
		console.log("detailslot.value " + detailSlot.value);
		
		var datetouse = new Date(new Date().setDate(new Date().getDate()-detail));
		dateconverted = convertDate(datetouse);
		console.log("datetouse is " + datetouse);
		console.log("dateconverted is " + dateconverted);
		
	    var obj = this; 
		rp(createOptionsDevicesDaysAgo(dateconverted))
			.then(
				function ($) {
					console.log($);
					var numdev = "";
					var numdays = "";
					if ($.Total == 1) {
						numdev = " device"
					} else {
						numdev = " devices";
					}
					if (detail == 1) {
						numdays = " day."
					} else {
						numdays = " days.";
					}
					
					speechOutput = $.Total + numdev + " have checked in the last " + detail + numdays;
					console.log(speechOutput);
					obj.emit(':tellWithCard', speechOutput, SKILL_NAME);
			})
			.catch(
				function (err) {
					console.log(err);
		});
   	},
   	'AMAZON.HelpIntent': function () {
        speechOutput = HELP_MESSAGE;
        var reprompt = HELP_REPROMPT;
        this.emit(':ask', speechOutput, reprompt);
    },
    'AMAZON.CancelIntent': function () {
        this.emit(':tell', STOP_MESSAGE);
    },
    'AMAZON.StopIntent': function () {
        this.emit(':tell', STOP_MESSAGE);
    }
};
